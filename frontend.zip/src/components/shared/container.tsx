﻿import type { ReactNode } from "react";

type ContainerProps = {
  children: ReactNode;
  className?: string;
};

export function Container({ children, className = "" }: ContainerProps) {
  return (
    <div className={`mx-auto w-full max-w-7xl px-4 text-right sm:px-6 lg:px-8 ${className}`}>
      {children}
    </div>
  );
}
