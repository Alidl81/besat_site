﻿import type { Metadata } from "next";
import { PreregistrationCard } from "@/components/auth/preregistration-card";

export const metadata: Metadata = {
  title: "پیش‌ثبت‌نام | مدرسه بعثت",
};

export default function RegistrationPage() {
  return (
    <main className="min-h-screen bg-[#f6f9fb] px-4 py-8 text-slate-900 sm:px-6 lg:px-8" dir="rtl">
      <PreregistrationCard />
    </main>
  );
}
