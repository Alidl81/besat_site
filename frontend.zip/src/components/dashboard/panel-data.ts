﻿export type PanelKey = "admin" | "unitManager" | "media" | "parents";
export type PanelSectionKey = string;

export type PanelMenuItem = {
  key: PanelSectionKey;
  label: string;
  href: string;
  icon: string;
  emptyText: string;
};

export type PanelCard = {
  title: string;
  value: number | null;
  note: string;
  icon: string;
};

export type PanelData = {
  panelKey: PanelKey;
  basePath: string;
  title: string;
  subtitle: string;
  roleTitle: string;
  menu: PanelMenuItem[];
  cards: PanelCard[];
};

const emptyText = "موردی برای نمایش وجود ندارد.";

export const panelData = {
  admin: {
    panelKey: "admin",
    basePath: "/admin",
    title: "به پنل مدیریت خوش آمدید",
    subtitle: "اطلاعات مدیریتی مجموعه در این بخش نمایش داده می‌شود.",
    roleTitle: "مدیر کل",
    menu: [
      { key: "overview", label: "داشبورد", href: "/admin", icon: "⌂", emptyText },
      { key: "units", label: "واحدها", href: "/admin/units", icon: "▥", emptyText },
      { key: "users", label: "کاربران", href: "/admin/users", icon: "♙", emptyText },
      { key: "content", label: "اخبار و اطلاعیه‌ها", href: "/admin/content", icon: "▦", emptyText },
      { key: "gallery", label: "گالری", href: "/admin/gallery", icon: "▧", emptyText },
      { key: "registrations", label: "ثبت‌نام‌ها", href: "/admin/registrations", icon: "▤", emptyText },
      { key: "messages", label: "پیام‌ها", href: "/admin/messages", icon: "✉", emptyText },
      { key: "profile", label: "پروفایل", href: "/admin/profile", icon: "◇", emptyText }, { key: "settings", label: "تنظیمات", href: "/admin/settings", icon: "⚙", emptyText },
    ],
    cards: [
      { title: "واحدها", value: null, note: emptyText, icon: "▥" },
      { title: "پیام‌ها", value: null, note: emptyText, icon: "✉" },
      { title: "محتوا", value: null, note: emptyText, icon: "▦" },
      { title: "درخواست‌ها", value: null, note: emptyText, icon: "□" },
    ],
  },
  unitManager: {
    panelKey: "unitManager",
    basePath: "/unit-manager",
    title: "به پنل مدیریت واحد خوش آمدید",
    subtitle: "اطلاعات مربوط به واحد آموزشی در این بخش نمایش داده می‌شود.",
    roleTitle: "مدیر واحد",
    menu: [
      { key: "overview", label: "داشبورد", href: "/unit-manager", icon: "⌂", emptyText },
      { key: "classes", label: "کلاس‌ها", href: "/unit-manager/classes", icon: "□", emptyText },
      { key: "students", label: "دانش‌آموزان", href: "/unit-manager/students", icon: "♙", emptyText },
      { key: "staff", label: "کارکنان", href: "/unit-manager/staff", icon: "♙", emptyText },
      { key: "attendance", label: "حضور و غیاب", href: "/unit-manager/attendance", icon: "▤", emptyText },
      { key: "programs", label: "برنامه‌ها", href: "/unit-manager/programs", icon: "▦", emptyText },
      { key: "content", label: "اخبار و اطلاعیه‌ها", href: "/unit-manager/content", icon: "▧", emptyText },
      { key: "messages", label: "پیام‌ها", href: "/unit-manager/messages", icon: "✉", emptyText },
      { key: "profile", label: "پروفایل", href: "/unit-manager/profile", icon: "◇", emptyText }, { key: "settings", label: "تنظیمات واحد", href: "/unit-manager/settings", icon: "⚙", emptyText },
    ],
    cards: [
      { title: "دانش‌آموزان", value: null, note: emptyText, icon: "♙" },
      { title: "معلمان و کارکنان", value: null, note: emptyText, icon: "♙" },
      { title: "پیام‌ها", value: null, note: emptyText, icon: "✉" },
      { title: "برنامه‌ها", value: null, note: emptyText, icon: "▦" },
    ],
  },
  media: {
    panelKey: "media",
    basePath: "/media",
    title: "به پنل رسانه و محتوای مدرسه خوش آمدید",
    subtitle: "محتوای رسانه‌ای و خبرهای واحد در این بخش مدیریت می‌شود.",
    roleTitle: "همکار رسانه",
    menu: [
      { key: "overview", label: "داشبورد", href: "/media", icon: "⌂", emptyText },
      { key: "news", label: "اخبار", href: "/media/news", icon: "▦", emptyText },
      { key: "announcements", label: "اطلاعیه‌ها", href: "/media/announcements", icon: "▧", emptyText },
      { key: "gallery", label: "گالری", href: "/media/gallery", icon: "▨", emptyText },
      { key: "albums", label: "آلبوم‌ها", href: "/media/albums", icon: "▤", emptyText },
      { key: "messages", label: "پیام‌ها", href: "/media/messages", icon: "✉", emptyText },
      { key: "profile", label: "پروفایل", href: "/media/profile", icon: "◇", emptyText }, { key: "settings", label: "تنظیمات", href: "/media/settings", icon: "⚙", emptyText },
    ],
    cards: [
      { title: "پیام‌ها", value: null, note: emptyText, icon: "✉" },
      { title: "گالری‌ها", value: null, note: emptyText, icon: "▨" },
      { title: "پیش‌نویس‌ها", value: null, note: emptyText, icon: "✎" },
      { title: "آماده انتشار", value: null, note: emptyText, icon: "✓" },
    ],
  },
  parents: {
    panelKey: "parents",
    basePath: "/parents",
    title: "خانواده گرامی، خوش آمدید",
    subtitle: "اطلاعات مربوط به فرزند و پیام‌های مدرسه در این بخش نمایش داده می‌شود.",
    roleTitle: "والدین",
    menu: [
      { key: "overview", label: "داشبورد", href: "/parents", icon: "⌂", emptyText },
      { key: "children", label: "فرزندان من", href: "/parents/children", icon: "♙", emptyText },
      { key: "programs", label: "برنامه‌ها", href: "/parents/programs", icon: "▦", emptyText },
      { key: "announcements", label: "اطلاعیه‌ها", href: "/parents/announcements", icon: "▧", emptyText },
      { key: "gallery", label: "گالری", href: "/parents/gallery", icon: "▨", emptyText },
      { key: "messages", label: "پیام‌ها", href: "/parents/messages", icon: "✉", emptyText },
      { key: "registration", label: "ثبت‌نام", href: "/parents/registration", icon: "▤", emptyText },
      { key: "profile", label: "پروفایل", href: "/parents/profile", icon: "◇", emptyText },
    ],
    cards: [
      { title: "فرزندان من", value: null, note: emptyText, icon: "♙" },
      { title: "پیام‌ها", value: null, note: emptyText, icon: "✉" },
      { title: "برنامه امروز", value: null, note: emptyText, icon: "▦" },
      { title: "اطلاعیه‌ها", value: null, note: emptyText, icon: "▧" },
    ],
  },
} satisfies Record<PanelKey, PanelData>;


